module.exports = {
  parser: 'babel-eslint',
  rules: {
    indent: ['error', 2, {'SwitchCase': 1}],
    semi: ['error', 'never']
  }
}
