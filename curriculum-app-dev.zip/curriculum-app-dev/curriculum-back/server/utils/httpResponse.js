// takes http code, info
// return status
// handle logging
