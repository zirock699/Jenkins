<template>
  <v-row align="center" class="home-section-two">
    <v-col sm="4" offset-sm="2">
      <img class="demo-screenshot" src="img/user_dashboard.png">
    </v-col>
    <v-col sm="4">
      <h2>See your progress</h2>
      <p>
        Easily keep track of everything you are learning in one place.
        Instant progress feedback helps you stay on track.
      </p>
    </v-col>
  </v-row>
</template>
