<template>
  <v-row align="center" class="home-section-three">
    <v-col sm="4" offset-sm="2">
      <h2>Achieve Your Goals</h2>
      <p>
        Check off tasks and projects as you go and receive
        badges as you achieve your goals.
      </p>
    </v-col>
    <v-col sm="4">
      <img class="demo-screenshot" src="img/display_curriculum.png">
    </v-col>
  </v-row> 
</template>
