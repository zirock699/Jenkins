export default {
  // getCurricula(state) {
  //   return state.
  // }
}
