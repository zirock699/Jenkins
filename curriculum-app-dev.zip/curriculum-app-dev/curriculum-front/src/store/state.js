export default {
  curricula: [],
  curriculaMeta: {},
  snackbar: {
    show: false,
    variant: 'success',
    message: ''
  },
  completeCounts: [],
  selectedCurriculum: {},
  loading: false
}
